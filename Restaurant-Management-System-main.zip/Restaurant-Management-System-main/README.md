# Restaurant-Management-System
Developed a Restaurant Management System using React.js to manage food menus and customer orders. Implemented component-based architecture for menu listing, cart management, and order summary. Used React hooks for state management and dynamic UI updates. The system improves efficiency and provides a smooth user experience.
